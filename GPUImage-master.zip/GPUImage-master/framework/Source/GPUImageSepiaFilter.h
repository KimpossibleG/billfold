#import "GPUImageColorMatrixFilter.h"

/// Simple sepia tone filter
@interface GPUImageSepiaFilter : GPUImageColorMatrixFilter

@end
