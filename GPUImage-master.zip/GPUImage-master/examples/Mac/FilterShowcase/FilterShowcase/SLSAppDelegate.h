#import <Cocoa/Cocoa.h>
#import "SLSFilterShowcaseWindowController.h"

@interface SLSAppDelegate : NSObject <NSApplicationDelegate>
{
    SLSFilterShowcaseWindowController *windowController;
}

@end
