#import <UIKit/UIKit.h>
#import "MultiViewViewController.h"

@interface MultiViewAppDelegate : UIResponder <UIApplicationDelegate>
{
    MultiViewViewController *rootViewController;
}

@property (strong, nonatomic) UIWindow *window;

@end
