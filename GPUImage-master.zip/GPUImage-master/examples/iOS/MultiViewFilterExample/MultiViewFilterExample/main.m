#import <UIKit/UIKit.h>

#import "MultiViewAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MultiViewAppDelegate class]));
    }
}
